## Respuestas
|  Valor (Valor Raw)  |  Descripción  |
| ---- | ---- |
|  Ejecutar cuando (run_when)  |  Especifica cuando las respuestas serán ejecutadas  |
|  Aplica prefix a las respuestas (prefix_to_replies)  |  Determina si el prefix es requerido para las respuestas  |

### Respuestas (replies)
|  Valor (Valor Raw)  |  Descripción  |
| ---- | ---- |
|  Método de detección (matchmethod)  |  Método de detección a utilizar  |
|  Palabra (word)  |  Palabras a usar para esta respuesta  |
|  Respuesta (reply)  |  Mensaje a responder  |
|  Tiempo de enfriamiento (ct)  |  Tiempo para poder volver a ejecutar esta respuesta  |
