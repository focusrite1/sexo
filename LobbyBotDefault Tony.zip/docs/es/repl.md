## Procedimiento hasta el primer arranque en Repl.it
Por favor espera...  
~~[Video]()~~  

Primero, accede a [repl.it](https://repl.it "repl.it")  
Si todavía no tienes una cuenta, haz click en `Sign up` arriba a la derecha  
Si ya tienes una, haz click en `Login` para iniciar sesión  
(No voy a explicar como iniciar sesión u obtener el email)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103261666-a173ee80-49e5-11eb-9ed3-314a469c29d2.png)  

Después de iniciar sesión, verás una pantalla como esta, presiona en + arriba a la derecha  
Y presiona en `Import From Github` dentro de la ventana que se abrió  
Pega `https://github.com/gomashio1596/Fortnite-LobbyBot-v2` en `Paste any repository URL` y haz click en `Import from Github`  

![Repl.it](https://user-images.githubusercontent.com/53356872/103262347-0defed00-49e8-11eb-9463-ebacf3370aab.png)  

Si la página cambiío (Llamaremos a esta página `Página del proyecto`)  
Haz click en `Run` arriba (Si estás en móvil, en el botón verde abajo a la derecha con un triangulo)  
y espera a que el bot arranque (Esto puede tomar un tiempo)  
Llamaremos `Consola` a la ventana con logs o console  
Si el bot arrancó, haz click en `Open in a new tab` arriba a la derecha (Si estás en móvil, abre `Web` y luego arriba a la derecha)  
(Llamamos a la página que se abrirá en este momento Página Web)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103263729-06324780-49ec-11eb-9b3f-f1eafcb4b17b.png)  

Si la página abrió, procede al [setup](setup.md#Procedimiento-hasta-el-setup "setup.md") del bot
