## Glosario
Fortnite
```
Un videojuego multijugador desarrollado por Epic Games y lanzado en 2017
```

Cliente de fortnite
```
Fortnite que todo el mundo suele jugar
```

Servidor de fortnite
```
Un sistema básico de juego que hace varias comunicaciones con el cliente de Fortnite
El resultado de la coincidencia y los datos del casillero, las funciones del partido, etc. son del lado del servidor.
```

Bot
```
Un programa que se comunica con el servidor de Fortnite e imita las funciones del cliente de Fortnite
No se limita a Fortnite-LobbyBot
No es el bot Fortnite el que se encontrará en la coincidencia
```

Web
```
Aquí hay una página web que Fortnite-LobbyBot iniciará
```

Licencia
```
Una regla de uso
```

Python
```
Uno de los lenguajes de programación
La característica es la legibilidad del código, muchas bibliotecas, etc.
```

Avatar
```
Un icono que se muestra en la lista de amigos y puede ser configurado en el centro de la fiesta
```

Status
```
Un texto que muestra en la lista de amigos
```
